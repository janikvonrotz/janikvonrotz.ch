@include('default.header')
@include('default.navigation')
@yield('content')
@include('default.footer')
