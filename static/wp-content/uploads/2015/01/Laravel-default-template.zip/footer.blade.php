</div>
<script src="{{ URL::asset('all.min.js') }}"></script>
</body>
</html>
